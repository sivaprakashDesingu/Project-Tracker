
var DATA = {    
    backendServer: 'http://localhost:8000/',
}

export default DATA